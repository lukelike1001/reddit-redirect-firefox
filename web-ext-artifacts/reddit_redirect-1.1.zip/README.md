# reddit-redirect-firefox
Firefox extension that redirects Reddit links to "new" Reddit.
